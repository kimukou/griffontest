def eventClosure1 = binding.variables.containsKey('eventSetClasspath') ? eventSetClasspath : {cl->}
eventSetClasspath = { cl ->
		println cl.dump()
    eventClosure1(cl)
    if(compilingPlugin('gmongo')) return

		griffonSettings.dependencyManager.mavenRepo("http://repo1.maven.org/maven2/com/gmongo/gmongo/" as String)
    griffonSettings.dependencyManager.addPluginDependency('gmongo', [
        conf: 'compile',
        group: 'com.gmongo',
        name: 'gmongo',
        version: '0.8'
    ])
}

